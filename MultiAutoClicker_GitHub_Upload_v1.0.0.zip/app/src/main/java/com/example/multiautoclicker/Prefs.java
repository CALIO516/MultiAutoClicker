package com.example.multiautoclicker;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    private final SharedPreferences p;
    public Prefs(Context c){ p=c.getSharedPreferences("multi_click", Context.MODE_PRIVATE); }
    public int count(){ return p.getInt("count",1); }
    public void setCount(int v){ p.edit().putInt("count",Math.max(1,Math.min(5,v))).apply(); }
    public int cps(int i){ return p.getInt("cps_"+i,5); }
    public void setCps(int i,int v){ p.edit().putInt("cps_"+i,Math.max(1,Math.min(20,v))).apply(); }
    public int x(int i,int def){ return p.getInt("x_"+i,def); }
    public int y(int i,int def){ return p.getInt("y_"+i,def); }
    public void setXY(int i,int x,int y){ p.edit().putInt("x_"+i,x).putInt("y_"+i,y).apply(); }
}
