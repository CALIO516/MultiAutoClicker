MultiAutoClicker v1.0.0
- Android 8.0+ (minSdk 26)
- 1~5 draggable overlay points
- Individual 1~20 CPS
- AccessibilityService dispatchGesture tap engine
- Start/Stop floating controller
- Foreground service notification

Build with Android Studio / Gradle using JDK 17+.
