package com.example.multiautoclicker;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class AutoClickAccessibilityService extends AccessibilityService {
    public static volatile AutoClickAccessibilityService instance;
    @Override protected void onServiceConnected(){ instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}
    @Override public void onDestroy(){ if(instance==this) instance=null; super.onDestroy(); }
    public boolean tap(float x,float y){
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription.StrokeDescription s=new GestureDescription.StrokeDescription(p,0,25);
        GestureDescription g=new GestureDescription.Builder().addStroke(s).build();
        return dispatchGesture(g,null,null);
    }
}
