package com.example.multiautoclicker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private Prefs prefs;
    private LinearLayout cpsBox;
    private TextView countLabel;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=new Prefs(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,32,32,32);
        ScrollView sv=new ScrollView(this); sv.addView(root); setContentView(sv);

        TextView title=t("멀티 오토클리커",26); title.setTextColor(Color.rgb(35,35,45)); root.addView(title);
        TextView sub=t("화면 위 1~5개 포인트를 배치하고 각 포인트를 지정 속도로 반복 터치합니다.",15); sub.setPadding(0,8,0,24); root.addView(sub);

        Button overlay=new Button(this); overlay.setText("① 다른 앱 위 표시 권한 열기"); overlay.setOnClickListener(v->openOverlayPermission()); root.addView(overlay);
        Button acc=new Button(this); acc.setText("② 접근성 서비스 설정 열기"); acc.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(acc);

        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,22,0,10);
        Button minus=new Button(this); minus.setText("−"); row.addView(minus,new LinearLayout.LayoutParams(0,56,1));
        countLabel=t("",20); countLabel.setGravity(Gravity.CENTER); row.addView(countLabel,new LinearLayout.LayoutParams(0,56,2));
        Button plus=new Button(this); plus.setText("+"); row.addView(plus,new LinearLayout.LayoutParams(0,56,1)); root.addView(row);
        minus.setOnClickListener(v->{ prefs.setCount(prefs.count()-1); rebuild(); });
        plus.setOnClickListener(v->{ prefs.setCount(prefs.count()+1); rebuild(); });

        cpsBox=new LinearLayout(this); cpsBox.setOrientation(LinearLayout.VERTICAL); root.addView(cpsBox);

        Button show=new Button(this); show.setText("오버레이 포인트 표시"); show.setOnClickListener(v->startOverlay()); root.addView(show);
        TextView hint=t("오버레이에서 포인트를 드래그해 위치를 정한 뒤 ▶를 누르면 시작합니다. ■로 즉시 정지할 수 있습니다.",14); hint.setPadding(0,18,0,0); root.addView(hint);
        rebuild();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=getPackageManager().PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);
    }

    private TextView t(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); return t; }
    private void rebuild(){
        countLabel.setText("터치 포인트  "+prefs.count()+"개"); cpsBox.removeAllViews();
        for(int i=0;i<prefs.count();i++){
            final int idx=i; LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL);
            TextView l=t("포인트 "+(i+1)+"   CPS",16); r.addView(l,new LinearLayout.LayoutParams(0,60,2));
            SeekBar sb=new SeekBar(this); sb.setMax(19); sb.setProgress(prefs.cps(i)-1); r.addView(sb,new LinearLayout.LayoutParams(0,60,4));
            TextView val=t(String.valueOf(prefs.cps(i)),16); val.setGravity(Gravity.CENTER); r.addView(val,new LinearLayout.LayoutParams(0,60,1));
            sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar s,int p,boolean f){ prefs.setCps(idx,p+1); val.setText(String.valueOf(p+1)); } public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} });
            cpsBox.addView(r);
        }
    }
    private void openOverlayPermission(){ Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())); startActivity(i); }
    private void startOverlay(){
        if(!Settings.canDrawOverlays(this)){ openOverlayPermission(); return; }
        Intent i=new Intent(this,OverlayService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); moveTaskToBack(true);
    }
}
