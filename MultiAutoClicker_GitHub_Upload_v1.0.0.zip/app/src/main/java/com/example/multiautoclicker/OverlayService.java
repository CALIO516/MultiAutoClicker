package com.example.multiautoclicker;

import android.app.*;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class OverlayService extends Service {
    private WindowManager wm; private Prefs prefs; private final List<View> points=new ArrayList<>(); private final List<WindowManager.LayoutParams> pointParams=new ArrayList<>();
    private LinearLayout controller; private Handler h; private boolean running=false; private long[] next;
    @Override public void onCreate(){ super.onCreate(); prefs=new Prefs(this); wm=(WindowManager)getSystemService(WINDOW_SERVICE); h=new Handler(Looper.getMainLooper()); createChannel(); startForeground(7,notification("포인트 위치를 설정하세요")); if(Settings.canDrawOverlays(this)){ createPoints(); createController(); } }
    private int type(){ return Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE; }
    private WindowManager.LayoutParams lp(int w,int h,int x,int y){ WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT); p.gravity=Gravity.TOP|Gravity.LEFT; p.x=x;p.y=y; return p; }
    private void createPoints(){
        int n=prefs.count(); for(int i=0;i<n;i++){ final int idx=i; TextView v=new TextView(this); v.setText(String.valueOf(i+1)); v.setTextColor(Color.WHITE); v.setTextSize(18); v.setGravity(Gravity.CENTER); v.setBackground(makeCircle()); int dx=100+i*100,dy=300+i*120; WindowManager.LayoutParams p=lp(64,64,prefs.x(i,dx),prefs.y(i,dy));
            v.setOnTouchListener(new View.OnTouchListener(){ float sx,sy; int ox,oy; public boolean onTouch(View vv,android.view.MotionEvent e){ if(running)return true; if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;return true;} if(e.getAction()==2){p.x=ox+(int)(e.getRawX()-sx);p.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(vv,p);return true;} if(e.getAction()==1){prefs.setXY(idx,p.x,p.y);return true;} return false;} }); wm.addView(v,p); points.add(v); pointParams.add(p); }
    }
    private android.graphics.drawable.Drawable makeCircle(){ android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setShape(android.graphics.drawable.GradientDrawable.OVAL); g.setColor(0x993949AB); g.setStroke(3,0xCCFFFFFF); return g; }
    private void createController(){ controller=new LinearLayout(this); controller.setOrientation(LinearLayout.HORIZONTAL); controller.setPadding(4,4,4,4); controller.setBackgroundColor(0xCC222222); Button start=b("▶"); Button stop=b("■"); Button close=b("×"); controller.addView(start);controller.addView(stop);controller.addView(close); WindowManager.LayoutParams p=lp(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,30,120); wm.addView(controller,p); start.setOnClickListener(v->begin()); stop.setOnClickListener(v->halt()); close.setOnClickListener(v->stopSelf()); }
    private Button b(String s){ Button b=new Button(this);b.setText(s);b.setTextSize(18);b.setMinWidth(64);return b; }
    private void begin(){ if(AutoClickAccessibilityService.instance==null){ Toast.makeText(this,"접근성 서비스에서 멀티 오토클리커를 먼저 켜주세요.",Toast.LENGTH_LONG).show(); return; } running=true; int n=prefs.count(); next=new long[n]; long now=SystemClock.uptimeMillis(); Arrays.fill(next,now); tick.run(); updateNotification("자동 클릭 실행 중"); }
    private void halt(){ running=false; h.removeCallbacks(tick); updateNotification("자동 클릭 정지됨"); }
    private final Runnable tick=new Runnable(){ public void run(){ if(!running)return; long now=SystemClock.uptimeMillis(); AutoClickAccessibilityService a=AutoClickAccessibilityService.instance; if(a==null){halt();return;} long soon=now+1000; for(int i=0;i<points.size();i++){ int cps=prefs.cps(i); long period=Math.max(50,1000L/cps); if(now>=next[i]){ WindowManager.LayoutParams p=pointParams.get(i); a.tap(p.x+32,p.y+32); next[i]=now+period; } soon=Math.min(soon,next[i]); } h.postDelayed(this,Math.max(10,soon-SystemClock.uptimeMillis())); } };
    private void createChannel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("clicker","멀티 오토클리커",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);} }
    private Notification notification(String text){ Intent stop=new Intent(this,OverlayService.class); PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE); Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"clicker"):new Notification.Builder(this); return b.setContentTitle("멀티 오토클리커").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setContentIntent(pi).setOngoing(true).build(); }
    private void updateNotification(String s){ ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7,notification(s)); }
    @Override public int onStartCommand(Intent i,int f,int id){ return START_STICKY; }
    @Override public android.os.IBinder onBind(Intent i){ return null; }
    @Override public void onDestroy(){ halt(); for(View v:points) try{wm.removeView(v);}catch(Exception ignored){} if(controller!=null) try{wm.removeView(controller);}catch(Exception ignored){} stopForeground(true); super.onDestroy(); }
}
